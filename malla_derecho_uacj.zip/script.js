function show(n) {
  document.querySelectorAll('.sem').forEach(s=>s.classList.remove('active'));
  document.getElementById('sem'+n).classList.add('active');
  drawLines(n);
}
function toggle(el) {
  el.classList.toggle('pendiente');
  el.classList.toggle('aprobada');
}
function drawLines(sem) {
  const svg = document.getElementById('prereqs');
  while(svg.firstChild) svg.removeChild(svg.firstChild);
  const defs = document.createElementNS('http://www.w3.org/2000/svg','defs');
  defs.innerHTML = '<marker id="arrow" markerWidth="10" markerHeight="10" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#888" /></marker>';
  svg.appendChild(defs);
  if(sem===2){
    const a = document.getElementById('m_1_1'),
          b = document.getElementById('m_2_1');
    if(a && b){
      const rA = a.getBoundingClientRect(),
            rB = b.getBoundingClientRect(),
            x1 = rA.right, y1 = rA.top + rA.height/2,
            x2 = rB.left, y2 = rB.top + rB.height/2;
      const line = document.createElementNS('http://www.w3.org/2000/svg','line');
      line.setAttribute('x1', x1); line.setAttribute('y1', y1);
      line.setAttribute('x2', x2); line.setAttribute('y2', y2);
      line.classList.add('pr');
      svg.appendChild(line);
    }
  }
}
document.getElementById('btnPDF').onclick = () => {
  import('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js')
  .then(() => import('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'))
  .then(({jsPDF}) => {
    html2canvas(document.body).then(canvas => {
      const img = canvas.toDataURL('image/png');
      const pdf = new jsPDF.jsPDF({ unit:'px', format:'letter' });
      pdf.addImage(img, 'PNG', 0, 0);
      pdf.save('malla_derecho_uacj.pdf');
    });
  }).catch(console.error);
};
show(1);
